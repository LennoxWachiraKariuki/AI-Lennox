
# AI Lennox Dashboard

A futuristic assistant dashboard for AI tasks, farming logs, health tracking, and planning.
